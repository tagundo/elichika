
version = "1.26.2"
__version__ = version
full_version = version

git_revision = "d5e07055a21db921a5da32b4c990372dab13239f"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
